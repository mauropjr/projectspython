.. python-simple-rest-client documentation master file, created by
   sphinx-quickstart on Sat Apr 15 17:57:28 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to python-simple-rest-client's documentation!
=====================================================

Simple REST client for python 3.5+, supports sync (with requests) and asyncio (with aiohttp) requests


Contents
---------
.. toctree::
   :maxdepth: 2

   installation
   quickstart

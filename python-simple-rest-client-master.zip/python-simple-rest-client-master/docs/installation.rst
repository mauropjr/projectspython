Installation
============

Install the latest stable release via pip::

    pip install simple-rest-client

python-simple-rest-client runs with `Python 3.5+ <https://travis-ci.org/allisson/python-simple-rest-client>`_ .